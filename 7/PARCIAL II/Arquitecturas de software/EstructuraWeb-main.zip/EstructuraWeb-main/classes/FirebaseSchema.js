class Schema {
  constructor(){
    //this.users = "Users";
  }
}
