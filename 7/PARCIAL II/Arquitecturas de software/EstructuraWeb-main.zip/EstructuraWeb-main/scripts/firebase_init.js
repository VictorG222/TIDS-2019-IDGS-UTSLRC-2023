
  var config = {
    
  };

  firebase.initializeApp(config);
  var auth = firebase.auth();