

<script type="text/javascript" src="./scripts/home.js?v1.0.0"></script>