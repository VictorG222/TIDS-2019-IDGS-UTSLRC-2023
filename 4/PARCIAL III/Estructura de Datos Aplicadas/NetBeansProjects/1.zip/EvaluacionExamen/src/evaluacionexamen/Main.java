/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evaluacionexamen;



public class Main {

    
    public static void main(String[] args) {
        Producto Producto1=new Producto(512128, "Pepsicola", "Grande", 50.99);
        Producto1.ImprimirProducto();
        
      
        Producto1.ComprarProducto(200);
        
    }
    
}
